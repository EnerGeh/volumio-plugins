#!/bin/bash

echo "Removing Syncthing"
# Uninstall dependendencies
apt-get remove -y Syncthing

echo "Done"
echo "pluginuninstallend"
